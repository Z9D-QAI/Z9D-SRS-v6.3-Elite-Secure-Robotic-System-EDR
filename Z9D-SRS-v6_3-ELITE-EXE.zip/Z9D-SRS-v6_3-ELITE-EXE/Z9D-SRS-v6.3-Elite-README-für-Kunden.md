# Z9D-SRS v6.3 Elite - Kurzanleitung fuer Kunden

**Diese Datei ist fuer Kunden bestimmt.**

---

## 1. Was ist Z9D-SRS v6.3 Elite?

Z9D-SRS v6.3 Elite ist ein lokales Sicherheits- und Schutzsystem fuer:

- Robotiksysteme
- Fernsteuerungen
- Bodenstationen
- Flug- und Drohnensysteme
- Schiffs- und Unterwassersysteme
- Landfahrzeuge und mobile Leitstellen
- Raumfahrt-, Satelliten- und Zukunftsplattformen

Die Software schuetzt lokale Systeme, Prozesse, Netzwerke und Kommunikationswege wie:

- WiFi / WLAN
- Bluetooth
- Infrarot
- Radio / Funk
- Cellular
- Satellite
- GNSS
- Telemetry
- Ethernet
- Acoustic

---

## 2. Was der Kunde bekommt

Sie erhalten von Z9D ein fertiges Paket mit den fuer Sie bestimmten Programmdateien.

Sie erhalten **nicht** den Serverbereich, keine Admin-Dateien und keine Betreiber-Konfiguration.

---

## 3. Start der Software

1. Paket entpacken
2. die gelieferte EXE oder die freigegebene Startdatei oeffnen
3. falls Windows nachfragt, Programm bestaetigen
4. die Hauptoberflaeche starten lassen

Wenn PowerShell oder Windows nach einer Freigabe fragt, nur die von Z9D gelieferte Originaldatei starten.

---

## 4. Erste Schritte im Programm

Nach dem Start bitte diese Punkte pruefen:

1. Geraete-ID anzeigen lassen
2. Schutzstatus pruefen
3. bei Bedarf das Einsatzprofil setzen
4. danach das Lizenz-Center oeffnen

---

## 5. Einsatzprofil richtig waehlen

Im Einsatzprofil koennen je nach Auslieferung unter anderem gesetzt werden:

- Einsatz-Domain
- Geraeterolle
- Deployment-Scope
- geschuetzte Kommunikationswege
- gekoppelte Gegenstelle
- Zielsysteme / gesteuerte Systeme

Beispiele:

- Bodenstation steuert Fluggeraet
- Leitstand steuert mehrere Robotereinheiten
- Schiff steuert weitere Subsysteme
- Satellit / Raumfahrzeug mit Bodenkontrolle
- mobile Landsteuereinheit mit gekoppelten Fahrzeugen

---

## 6. Lizenz-Center

Im Lizenz-Center waehlen Sie die passende Produktgruppe, z. B.:

- SRS Remote
- SRS Autonomous
- SRS AI
- SRS Universal OEM

Danach pruefen Sie:

- passt die Geraeterolle?
- passt die Domain?
- ist eine Gegenstelle einzutragen?
- muessen mehrere Zielsysteme hinterlegt werden?

Erst danach die Anfrage absenden.

---

## 7. Pairing / gekoppelte Systeme

Es gibt drei typische Faelle:

### Einzelgeraet

- ein einzelnes System
- keine Gegenstelle noetig

### Twin-System

- z. B. Fahrzeug + Bodenstation
- Gegenstelle eintragen

### Control-Cluster

- ein Steuerknoten kontrolliert mehrere Zielsysteme
- mehrere Zielsystem-IDs hinterlegen

Bitte nur echte zusammengehoerige Systeme koppeln.

---

## 8. Nach Kauf oder Freigabe

Nach Bestellung, Zahlung oder OEM-Freigabe:

1. Status pruefen
2. Lizenzaktivierung abwarten
3. Anwendung ggf. neu oeffnen
4. kontrollieren, ob Schutz- und Lizenzstatus aktiv sind

---

## 9. Support

Bei Fragen oder Problemen verwenden Sie die Support-Seite des Systems oder kontaktieren Sie Z9D.

Typische Supportfaelle:

- Aktivierung noch offen
- falsche Geraeterolle gewaehlt
- Gegenstelle geaendert
- neue Zielsysteme hinzugekommen
- OEM-/Mehrfachsysteme sollen erweitert werden

---

## 10. Wichtige Hinweise fuer Kunden

- keine Admin-Dateien veraendern
- keine Serverdateien anfordern oder kopieren
- nur Originaldateien von Z9D verwenden
- bei Aenderung von Rolle, Gegenstelle oder Zielsystemen ggf. neue Freigabe einholen
- lokale Sicherheitssoftware und Windows-Schutz nicht absichtlich deaktivieren

## 11. Missbrauchsschutz / Anti-Raubkopie

- nur freigegebene Originalversionen von Z9D verwenden
- keine raubkopierten, manipulierten oder trojanischen Gleichkopien einsetzen
- keine nicht autorisierten Klonversionen weitergeben oder betreiben
- bei Verdacht auf Manipulation, Missbrauch oder trojanische Kopien sofort Support informieren

## 12. Zweckentfremdung und Aussetzung von Aktivierungen

- der Schutz von Civilisten und unbeteiligten Zivilpersonen hat Vorrang
- eine Nutzung oder Zweckentfremdung gegen die Civilbevoelkerung ist nicht freigegeben
- dies gilt auch fuer missbraeuchliche Flotten-, Fernsteuerungs- oder Plattformnutzung
- Z9D behaelt sich das Recht vor, Aktivierungen einzelner Systeme, ganzer Flotten, Versionen oder eines ganzen Landes zu sperren, zu deaktivieren, zu stoppen oder auszusetzen
- dies kann auch bereits aktivierte Versionen betreffen, bis die Lage geklaert und richtiggestellt wurde

---

## 13. Kurzfassung

- Programm starten
- Einsatzprofil setzen
- Lizenz-Center oeffnen
- richtige Rolle und Domain waehlen
- bei Bedarf Gegenstelle und Zielsysteme eintragen
- Anfrage absenden
- Status und Aktivierung pruefen
